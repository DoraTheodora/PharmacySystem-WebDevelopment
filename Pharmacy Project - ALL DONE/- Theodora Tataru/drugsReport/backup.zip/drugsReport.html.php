<!DOCTYPE html>
<!--- Theodora Tataru C00231174--->
<!--- Tutor: Catherine Moloney--->
<!--- February 2018 --->

<!--- Drugs Report  --->
<html>
<head> <title> Name of the Pharmacy</title>


	<!-- CSS FILE--> <link rel="stylesheet" type="text/css" href="../../pharmacy/css/styles.css">

	<script type="text/javascript" src="../../pharmacy/js/popUp.js"></script>
    <script type="text/javascript" src="../../pharmacy/js/alertbox.js"></script>
    <script type="text/javascript" src="../../pharmacy/js/leftnav.js"></script>
    
</head>

<!-- //////////////////////////////////////////////////////////////////// -->
<!-- Left side menu -->
<body id="main">
	<?php include '../../pharmacy/leftnav.php'; ?>
<!-- //////////////////////////////////////////////////////////////////// -->
<div id="maincontent">
	
<!-- Here is where the report will be shown -->	
	<form class="boxshadow" action="drugsReport.html.php" method="POST" name="reportForm">
		<h2> Drugs Report <h2>
		<br> 
		<input type="hidden" name="choice">
	</form>	
	<!-- Order Buttons-->
	<div class="buttons">
		<input type="button" id="BrandName" value="Sort By Brand Name" onclick="brandName()" title="Click here to sort the report by Brand Name">
		<input type="button" id="Name" value="Sort By Supplier Name" onclick="supplierName()" title="Click here to sort the report by Supplier Name">
		
		<button type="button" onclick="supplierName()">Click Me! Enabled </button> 
<button type="button" disabled=""> Click Me! Disabled</button>
		
	</div>
	<!--changing the order of the report-->
	<script>
		function brandName()
		{
			document.reportForm.choice.value="BrandName";
			document.reportForm.submit();
		}
		function supplierName()
		{
			document.reportForm.choice.value="Name";
			document.reportForm.submit();
		}
	</script>
	
	<?php
	$choice = "BrandName"; // choice by default
	
	if(ISSET($_POST['choice']))
	{
		$choice=$_POST['choice'];
	}
	if($choice=='Name')
	{
		?>
			<script>
				document.getElementById("BrandName").disabled=false;
				document.getElementById("Name").disabled=true;
			</script>
		<?php
		$sql = "SELECT Drug.BrandName, Drug.GenericName, Drug.Form, Drug.Strength, Drug.Quantity, Supplier.Name 
				FROM(Drug INNER JOIN Supplier ON Drug.SupplierID=Supplier.SupplierID) WHERE Drug.DeletionFlag = 0
				ORDER BY Supplier.Name DESC";
				
		include '../db.inc.php';
		produceReport($con,$sql);
	}
	else // if choice == SupplierName
	{
		?>
			<script>
				document.getElementById("BrandName").disabled=true;
				document.getElementById("Name").disabled=false;
			</script>
		<?php
		$sql = "SELECT Drug.BrandName, Drug.GenericName, Drug.Form, Drug.Strength, Drug.Quantity, Supplier.Name 
				FROM(Drug INNER JOIN Supplier ON Drug.SupplierID=Supplier.SupplierID) WHERE Drug.DeletionFlag = 0
				ORDER BY Drug.BrandName DESC";
				
		include '../db.inc.php';
		produceReport($con,$sql);
		
	}
	
	include '../db.inc.php';
	function produceReport($con,$sql)
	{
		include '../db.inc.php';
		$result = mysqli_query($con,$sql);
		
		echo "<div class='table boxshadow'>
				<table class=''> 
					<thead>
						<tr>
							<th class='Head'> Brand Name </th>
							<th class='Head'> Generic Name </th>
							<th class='Head'> Form </th>
							<th class='Head'> Strength </th>
							<th class='Head'> Quantity </th>
							<th class='Head'> Supplier Name </th>
						</tr>
					</thead>";
		while($row=mysqli_fetch_array($result)) // display the data
		{
			echo "<tbody>
					<tr>
					<td>".$row['BrandName']."</td>
					<td>".$row['GenericName']."</td>
					<td>".$row['Form']."</td>
					<td>".$row['Strength']."</td>
					<td>".$row['Quantity']."</td>
					<td>".$row['Name']."</td>
					</tr>
				</tbody>";
		}
		
		echo "</table></div>";
	}
	mysqli_close($con);
	?>
</div>	
	<?php //include '../../pharmacy/footer.php'; ?> <!-- POP UP WINDOS -->
</body>
</html>
